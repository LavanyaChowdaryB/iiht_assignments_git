package tweet;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Scanner;

public class logintweet {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="insert into login(first_name,email_id,password) values(?,?,?)";
	static final String Query1="Select * from login where email_id=? AND password=?";
	static final String Query2="update  login set password=? where password=?";
	static final String Query3="update login set password=? where email_id=?";
	static final String Queryp="insert into tweet (user_name,email_id,post,date,status) values(?,?,?,?,'logged in')";
	static final String Queryva="Select * from tweet";
	static final String Queryvh="Select * from tweet where user_name=?";
	static final String Querylo="update tweet set status='logout'";
	


	public static void main(String[] args) throws IOException {
System.out.println("********WELCOME TO TWITTER*********");
Scanner sc=new Scanner(System.in);
System.out.println("Enter 1 for --> User login \n 2 for --> User Registration \n 3 for -->Forgot password \n 4 for-->Exit");
int i=sc.nextInt();

switch(i) {

case 1:
	try(Connection conn=DriverManager.getConnection(DB_url, user, pass) ;
			PreparedStatement st=conn.prepareStatement(Query1);)
	{
	System.out.println("login page ");
	Scanner sc1=new Scanner(System.in);
	System.out.println("enter email id ");
	String email=sc.next();
	System.out.println("enter password ");
	String pass1=sc.next();
	st.setString(1, email);
	st.setString(2, pass1);
	ResultSet rs=st.executeQuery();
	if(rs.next()) {
		System.out.println("login successfull:");
		System.out.println("*-*-*-*-*-*-*");
		System.out.println();
		System.out.println("select 1 for--> view all posts \n select 2 for--> post a new tweet \n select 3 for --> view his post \n select 4 for -->Reset password \n select 5 for Logout");
		Scanner scanner=new Scanner(System.in);
        System.out.println("Select the option");
        int a=scanner.nextInt();
	
        
        switch(a)
        {
        case 1:
        	System.out.println("view all posts");
        	try(Connection conn1=DriverManager.getConnection(DB_url, user, pass);
    				Statement st1=conn.createStatement();
    				ResultSet rs1=st.executeQuery(Queryva);)
        	{
    			
    			while(rs1.next()) {
    				System.out.println("User Name ="+ rs1.getString("user_name"));
    				System.out.println("email id ="+ rs1.getString("email_id"));
    				System.out.println(" tweets ="+ rs1.getString("post"));
    				System.out.println(" date ="+ rs1.getString("date"));
    				System.out.println("Status ="+ rs1.getString("status"));
    						
    			}
    		

    	}
        	catch(SQLException e) 
        	{e.printStackTrace();}
        	
        	break;

        case 2:
        	System.out.println("post a New tweet");
        	
        	try (Connection conn2=DriverManager.getConnection(DB_url, user, pass);
        			PreparedStatement ps=conn2.prepareStatement(Queryp);)
        			{
        			
        		    BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        		    System.out.println("Type to post");
        	     	String i1=br.readLine();
        	     	ps.setString(1, rs.getString("first_name"));
        	     	ps.setString(2, rs.getString("email_id"));
        			ps.setString(3,i1);
        			ps.setString(4,LocalDate.now().toString());
        			ps.executeUpdate();
        			System.out.println("Successfully Posted");
        			}
        			catch(SQLException e) {
        				System.out.println(e.getMessage());
        			}
        	break;
        	
        	
        case 3:
        	System.out.println("view his posts");
        	
        	try(Connection conn3=DriverManager.getConnection(DB_url, user, pass) ;
    				PreparedStatement st3=conn.prepareStatement(Queryvh);
        			){
        		
        		Scanner sc2 = new Scanner(System.in);
    			System.out.println("enter user name");
    			String uname=sc2.next();
    			st3.setString(1,uname);
    			ResultSet rs3=st.executeQuery();
    			while(rs3.next()) {
    				System.out.println("User Name ="+ rs3.getString("user_name"));
    				System.out.println("email id ="+ rs3.getString("email_id"));
    				System.out.println(" tweet ="+ rs3.getString("post"));
    				System.out.println(" date ="+ rs3.getString("date"));
    				System.out.println("Status ="+ rs3.getString("status"));
    						
    			}}
    			catch(SQLException e) {
    				System.out.println(e.getMessage());}
        
        break;
        
		
      case 4:
        System.out.println("Reset password");
    	try (Connection conn6=DriverManager.getConnection(DB_url, user, pass);
    			PreparedStatement ps=conn6.prepareStatement(Query2);){
    			
    			Scanner sc3 = new Scanner(System.in);
    			System.out.println("enter new password");
    			String i1=sc3.next();
    			System.out.println("enter old password");
    			String i2=sc3.next();
    			ps.setString(1,i1);
    			ps.setString(2, i2);
    			ps.executeUpdate();
    			
    			System.out.println("Successfully updated");
    	}
    			catch(SQLException e) {
    				System.out.println(e.getMessage());
    			}break;
	
	
    			
               case 5:
               System.out.println("logout");
               System.out.println("enter logout");
               Scanner sc3 = new Scanner(System.in);
               String status1;
               try (Connection conn7=DriverManager.getConnection(DB_url, user, pass);
		       PreparedStatement ps=conn7.prepareStatement(Querylo);)

               {
//            	   String logout ="logout";
//            	   ps.setString(1, logout);
		       ps.executeUpdate();
		       System.out.println("successfully logged out");
	//break;
		
               }
	catch(SQLException e) {
		e.printStackTrace();
	}
	
	break;
        
default:System.out.println("not able to logout");}}}
    			catch(SQLException e) 
   			{e.printStackTrace();}
        break;
        case 2:
        
    		    System.out.println("Registrtion page:");
        		try(Connection conn=DriverManager.getConnection(DB_url, user, pass);
        				PreparedStatement ps= conn.prepareStatement(Query);) {
        			Scanner sc2=new Scanner(System.in);
        			System.out.println("enter first name ");
        			String fname=sc2.next();
        			System.out.println("enter email id ");
        			String emaill=sc2.next();
        			System.out.println("enter password ");
        			String passs=sc2.next();
        			
        			ps.setString(1, fname);
        			ps.setString(2, emaill);
        			ps.setString(3, passs);
        			ps.executeUpdate();
        			System.out.println("Registered successfully");
        			
        	}catch(SQLException e) {
        		e.printStackTrace();
        	}
        		break;
	
        	
        case 3:
                
        System.out.println("Forgot password");
        try (Connection conn5=DriverManager.getConnection(DB_url, user, pass);
		PreparedStatement ps5=conn5.prepareStatement(Query3);){
		
		Scanner sc3 = new Scanner(System.in);
		System.out.println("enter email id");
		String i1=sc3.next();
		System.out.println("enter new password");
		String i2=sc3.next();
		ps5.setString(1,i2);
		ps5.setString(2, i1);
		ps5.executeUpdate();
		
		System.out.println("Successfully changed");
}
		catch(SQLException e1)
{
			}break;
	}}

}
			

	
	

