package jdbc;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class update {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="update customer set cust_age=33 where cust_id=?";
	
	public static void main(String[] args) {
	try (Connection conn=DriverManager.getConnection(DB_url, user, pass);
	PreparedStatement ps=conn.prepareStatement(Query);)
	{
	Scanner sc = new Scanner(System.in);
	System.out.println("enter id");
	int i=sc.nextInt();
	ps.setInt(1,i);
	ps.executeUpdate();
	System.out.println("Successfully updated");
	}
	catch(SQLException e) {
		System.out.println(e.getMessage());
	}
	}

}
