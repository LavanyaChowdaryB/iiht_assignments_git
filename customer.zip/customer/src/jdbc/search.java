package jdbc;

import java.sql.*;
public class search {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="select * from customer";
	
	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass) ;
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery(Query);){
			
			while(rs.next()) {
				System.out.println("customer Id ="+ rs.getInt("cust_id"));
				System.out.println("customer firstname ="+ rs.getString("cust_fname"));
				System.out.println("customer lastname ="+ rs.getString("cust_lname"));
				System.out.println("customer city="+ rs.getString("cust_city"));
				System.out.println("customer age ="+ rs.getInt("cust_age"));
				System.out.println("customer gender="+ rs.getString("cust_gender"));
						
			}
		

	}catch(SQLException e) {

}
}}