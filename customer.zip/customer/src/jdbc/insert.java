package jdbc;
import java.sql.*;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;


public class insert {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="insert into customer(cust_id,cust_fname,cust_lname,cust_city,cust_age,cust_gender)values(?,?,?,?,?,?)";
	

	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass);
				PreparedStatement ps= conn.prepareStatement(Query);) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter customer Id ");
			int cid=sc.nextInt();
			System.out.println("enter customer firstname ");
			String cfname=sc.next();
			System.out.println("enter customer lastname ");
			String clname=sc.next();
			System.out.println("enter customer city ");
			String ccity=sc.next();
			System.out.println("enter customer age ");
			String cage=sc.next();
			System.out.println("enter customer gender ");
			String cgender=sc.next();
			
			ps.setInt(1, cid);
			ps.setString(2, cfname);
			ps.setString(3, clname);
			ps.setString(4, ccity);
			ps.setString(5, cage);
			ps.setString(6, cgender);
			ps.executeUpdate();
			System.out.println("Updated successfully");
		}catch(SQLException e) {
			
	}
}}
