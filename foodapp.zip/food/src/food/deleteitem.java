package food;
import java.sql.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;


public class deleteitem {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="Delete from food where item=?";

	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass);
				PreparedStatement ps=conn.prepareStatement(Query);){
				Scanner sc=new Scanner(System.in);
				System.out.println("Enter food item");
				int cid=sc.nextInt();
				ps.setInt(1, cid);
				ps.executeUpdate();
				System.out.println("Deleted successfully");
						
				
			}
			
			
		catch(SQLException e) {
			e.printStackTrace();
		}
				

	}

}

