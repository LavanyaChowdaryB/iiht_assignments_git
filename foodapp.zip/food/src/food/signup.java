package food;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class signup {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="insert into login(first_name,email_id,password) values(?,?,?)";

	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass);
				PreparedStatement ps= conn.prepareStatement(Query);) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter first name ");
			String fname=sc.next();
			System.out.println("enter email id ");
			String email=sc.next();
			System.out.println("enter password ");
			String pass=sc.next();
			
	}catch(SQLException e) {
		e.printStackTrace();
	}
	}

}
