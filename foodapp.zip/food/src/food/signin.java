package food;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class signin {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="Select * from login where email=? AND password=?";


	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass);
				PreparedStatement ps= conn.prepareStatement(Query);) {
			Scanner sc=new Scanner(System.in);
			System.out.println("enter email id ");
			String email=sc.next();
			System.out.println("enter password ");
			String pass=sc.next();
			
			ps.setString(1, email);
			ps.setString(2, pass);
			ResultSet rs=ps.executeQuery();
			if(rs.next()) {
			System.out.println("login successful");
		}else {
			System.out.println("login failed");}
		
	}catch(SQLException e) {
		e.printStackTrace();
		}}}