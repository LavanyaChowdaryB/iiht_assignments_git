package food;

import java.sql.*;
public class search {
	static final String DB_url="jdbc:mysql://localhost:3306/assignment1";
	static final String user="root";
	static final String pass="pass@word1";
	static final String Query="select from food where cust_id=?";
	
	public static void main(String[] args) {
		try(Connection conn=DriverManager.getConnection(DB_url, user, pass) ;
				Statement st=conn.createStatement();
				ResultSet rs=st.executeQuery(Query);){
			
			while(rs.next()) {
				System.out.println("customer Id ="+ rs.getInt("cust_id"));
				System.out.println("customer name ="+ rs.getString("cust_name"));
				System.out.println("customer address ="+ rs.getString("cust_addr"));
				System.out.println("customer number="+ rs.getString("cust_num"));
				System.out.println(" fooditem ="+ rs.getInt("food_item"));
				System.out.println("food quantity="+ rs.getString("quantity"));
						
			}
		

	}catch(SQLException e) {

}
}}